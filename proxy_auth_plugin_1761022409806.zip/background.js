
var config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "118.193.59.165",
            port: parseInt(17673)
        },
        bypassList: ["localhost"]
    }
};

chrome.proxy.settings.set({config: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "u15ef7771569d05be",
            password: "CengizzAtay"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {urls: ["<all_urls>"]},
    ['blocking']
);
